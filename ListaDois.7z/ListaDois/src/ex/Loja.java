package ex;

import java.util.ArrayList;

public class Loja {
	private ArrayList<Livros> li;
	
	public Loja() {
		li = new ArrayList<Livros>();					// � um metodo logo () � necessario
	}
	public void addLivro(Livros l) {					// add um livro a loja
		if(l!=null) {										// se for diferente de null 
			li.add(l);
		}	
	}
	public void exibirL() {
		for(Livros l: li) {
			if(l.getStatus()) {
				l.informacoes();
			}
		}
	}
	
	public int comprar(String t, int qt, Formatos fo) {
		for(Livros l: li) {								//entra dentro do array
			if(l.getTitulo().equals(t)) {					//verifica se titulo s�o iguais
				if(l.getQuantidade()<qt) {						//verifica se quantidade esta disponivel
					qt= l.getQuantidade();							//iguala a quantidade comprada a quantidade disponivel
				}
				
				System.out.println("Quantidade disponivel: "+qt);
				l.retirar(qt);									//retira qt do estoque			
				System.out.println("Quantidade em estoque: "+l.getQuantidade());
				return qt*l.getPreco(fo);						//retorna  o valor a ser pago
			}
		}
		return 0;
	}
}
