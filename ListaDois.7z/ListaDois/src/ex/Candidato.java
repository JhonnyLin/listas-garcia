package ex;

public class Candidato {
	private String nome;
	private Partido p;
	
	public Candidato(String nome, Partido p) {
		this.nome = nome;
		this.p = p;
		
	}
	public String getNome() {
		return nome;
	}
	public String getPartido() {
		return p.getNPartido();
	}
	public void trocaPartido(Partido p) {
		if(this.p != p) {
			this.p.desfiliacao(nome);
			this.p=p;
			}
		
	}
}
