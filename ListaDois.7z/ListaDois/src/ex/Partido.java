package ex;

import java.util.ArrayList;

public class Partido {
	private ArrayList<Candidato> candidatos;							//array de candidatos
	private Ideologia i;												//enum de ideologia
	private String nome, sigla;				
	private int num;
	
	public Partido(String nome, String sigla,int num, Ideologia i) {	//para criar um partido � preciso ter esses elemnetos
		this.i= i;														//inicializando as variaveis como o valor recebido pelo parametro
		this.nome = nome;
		this.sigla = sigla;
		this.num = num;
		candidatos = new ArrayList<Candidato>();						//iniciando o array
	}
	
	public void filiacao(Candidato c) {									//metodo para add candidato
		if(c != null) {													//se n for nulo
			candidatos.add(c);											//add candidato dentro do Array de Candidatos
			System.out.println("Filiado");
		}
	}
	
	public boolean desfiliacao(String s) {								//metodo para remover
		for(Candidato can: candidatos) {								//for it
			if(can.getNome().equals(s)) {								//se forem iguais nome do candidato do parametro e o da Array
				 candidatos.remove(candidatos.indexOf(can));			//pega o indice do array e remove do array
				 return true;											//removendo true
			}
		}
		return true;													//se n existe tbem true
	}
	
	public void getPoliticos(){										//Nome Filiados
		if(candidatos.size()!=0) {										//se Array tem tamanho diferente de 0
			for(Candidato can: candidatos) {							//for it corre por todo o Array
				System.out.println(can.getNome()); 									//retorna o nome que esta em cada possi��o
			}
		}																//se n null
		
	}
	
	public String getNPartido() {										//nome do partido
		return nome;
	}
	
	public String getSPartido() {										//sigla do partido
		return sigla;
	}
	
	public Ideologia getIdeologia() {
		return i;
	}
	
	public int getNum() {
		return num;
	}
	
	public void informacoesPartido() {									//so printa as informa��es
		System.out.println(this.getNPartido());
		System.out.println(this.getSPartido());
		System.out.println(this.getNum());
		System.out.println(this.getIdeologia());
		getPoliticos();
		
	}
}

