package ex;

public class Cliente {
	private String nome;
	private double limite, saldo, auxLimi;
	
	public Cliente(String nome, double limite, double saldo) {
		this.nome = nome;
		this.limite = limite;
		this.saldo = saldo;
		this.auxLimi = limite;
	}
	public void depositar(double d){
		if(this.limite<this.auxLimi) {						//se limite menor que aux
			if((this.limite+=d)>this.auxLimi) {					//se limite somado a d for maior q aux
				d =limite-auxLimi;									//d igual limite menos aux
				limite = auxLimi;									//limite igual a aux
			}
		}											
				this.saldo+=d;										//soma d a saldo 
		
		
	}
	public boolean sacar(double d){				//60
		double aux = saldo;						//aux igual saldo 50
		if(d<limite+saldo) {					//d menor que limete mais saldo
			if((aux-=d)<=0) {						// aux menosd menor ou igual a zero;
				this.saldo=0;							//saldo igual a zero;
				limite+=aux;							//limite mais aux que deve ser negativo ou zero
							
			}else {									// se maior
				this.saldo=aux;							// saldo igual aux
			}
			return true;							//retorna true	
		}										// se n retorna false
		return false;
	}
	public String getNome(){
		return this.nome;
	}
	public double getLimite(){
		return limite;
	}
	public double getSaldo(){
		return saldo;
	}
	public double checarSaldo() {
		return saldo+limite;
	}
}
