package ex;

public class Bateria {
	private int energia;
	
	
	public Bateria(){
		this.energia = 100;
	}
	public boolean semCarga() {
		return energia==0;
	}
	public void carrega() {
		this.energia+=5;
	}
	public void descarrega() {
		this.energia-=10;
	}
	public void newBateria() {
		
			energia += 100 -energia;
		
	}
	public int getEnergia() {
		return this.energia;
	}
}
