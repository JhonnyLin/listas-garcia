package ex;

public class Celular {
	Bateria b;
	private String nome;
	private int identificador;
	private boolean status;
	
	public Celular(String nome, int identificador, Bateria b) {
		this.nome = nome;
		this.identificador= identificador;
		this.b = b;
		this.status = false;
	}
	public void ligar(boolean a) {					//LIGA
		System.out.println("entando");
		if(a == false) {
			System.out.println("entando if 1");
			if(b.getEnergia() >=20) {
				System.out.println(nome);
				System.out.println(identificador);
				b.descarrega();
				b.descarrega();
				status = true;
			}else {
				System.out.println("bateria fraca");
			}
		}
	}
	public void desliga() {					//DESLIGA
		if(status) {
			if(b.getEnergia()>20) {
				System.out.println("Desligando");
			}
			b.descarrega();
		}
	}
	public void som(){						//SOM
		if(status) {
			if(b.getEnergia()>=10) {
				b.descarrega();
				System.out.println("tocando");
			}
		}
	}
	public boolean statusC() {
		return status=false;
	}
	
	public void trocarBateria(Bateria a) {
		this.b = a;
	}
}
