package ex;

public enum Formatos {
	EPUB, PDF, FISICO;
}
