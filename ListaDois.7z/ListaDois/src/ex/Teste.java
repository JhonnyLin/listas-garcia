//falta fazer troca bateria



package ex;

public class Teste {

	public static void main(String[] args) {
		//Ex1
		/*Partido p = new Partido("Partido Terrorista", "PT", 13, Ideologia.Esquerda);
		Partido p1 = new Partido("Caracu", "CU", 1, Ideologia.CentroE);
		p.informacoesPartido();
		p1.informacoesPartido();
		Candidato c = new Candidato("jhonny", p1);
		Candidato c1 = new Candidato("lin", p1);
		p1.filiacao(c1);
		p1.filiacao(c);
		p1.informacoesPartido();
		p.filiacao(c1);
		c1.trocaPartido(p);
		p1.informacoesPartido();
		p.informacoesPartido();*/
		//Ex2
		/*Doc doc = new Doc();
		Cliente cli = new Cliente("jhonny",30, 50);
		Cliente cli1 = new Cliente("Lin", 100, 30);
		System.out.println(cli.checarSaldo());				//80
		if(cli.sacar(200)) {								//for�ar erro
			System.out.println("deu ruim");
		}else {
			System.out.println("Sem saldo");
		}
		if(cli.sacar(51)) {									//sacar
			System.out.println(cli.getLimite());			//29
			System.out.println(cli.getSaldo());				//0
		}else {
			System.out.println("deu ruim");
		}
		cli.depositar(250);
		System.out.println(cli.getLimite());			//30
		System.out.println(cli.getSaldo());				//249
		 
		doc.transferencia(cli, cli1, 249);
		System.out.println(cli.getLimite());			//30
		System.out.println(cli.getSaldo());				//0
		System.out.println(cli1.getLimite());			//100
		System.out.println(cli1.getSaldo());			//279
		*/
		//Ex3
		/*Bateria b = new Bateria();
		Celular c = new Celular("jhonny", 1997, b);
		System.out.println(b.getEnergia());//100
		c.ligar(c.statusC());
		System.out.println(b.getEnergia());//80
		c.som();
		System.out.println(b.getEnergia());//70
		c.b.carrega();
		System.out.println(b.getEnergia());//75
		c.desliga();
		System.out.println(b.getEnergia());//65
		c.ligar(c.statusC());
		System.out.println(b.getEnergia());//45
		Bateria b1 = new Bateria();
		c.trocarBateria(b1);
		System.out.println(c.b.getEnergia());//100*/
		//Ex4
		Loja lj = new Loja();					//abre loja
		Livros l1 = new Livros("Kkk",3);		//cria os livros
		Livros l2 = new Livros("Haha",100);
		Livros l3 = new Livros("Rum",6);
		Livros l4 = new Livros("Affs",0);
		lj.addLivro(l1);						//add a loja
		lj.addLivro(l2);
		lj.addLivro(l3);
		lj.addLivro(l4);
		lj.exibirL();							//exir os 3 primeiros
		System.out.println("Pre�o do livro de EPUB: "+l1.getPreco(Formatos.EPUB));				//verifica o preco pelo formato
		System.out.println("Pre�o do livro de PDF "+l1.getPreco(Formatos.PDF));
		System.out.println("Pre�o do livro de FISICO "+l1.getPreco(Formatos.FISICO));
		System.out.println("Formato do livro de R$ 20: "+l1.getFormato(20));					//verificando formato por pre�o
		System.out.println("Formato do livro de R$ 40: "+l1.getFormato(40));
		System.out.println("Formato do livro de R$ 80: "+l1.getFormato(80));
		System.out.println("Total dos Livros: "+lj.comprar("Rum", 10, Formatos.PDF));			//comprar os 6
		lj.exibirL();
		
		}

}
