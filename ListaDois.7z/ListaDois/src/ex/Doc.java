package ex;

public class Doc {
	
	public Doc() {
		
	}
	
	public boolean transferencia(Cliente c1, Cliente c2 , double vlr){						
		if(c1.sacar(vlr)) {							//se c for sacar retorna vedd
			c2.depositar(vlr);							//c1 chama depositar e passa a quantia
			return true;								//retorna vdd
		}											//se n�o
		return false;									//retorna ff
	}
}
