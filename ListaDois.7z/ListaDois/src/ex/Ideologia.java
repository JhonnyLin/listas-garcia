package ex;

public enum Ideologia {
	Centro, CentroE ,CentroD , Esquerda, Direita;
}
