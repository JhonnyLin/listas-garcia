package ex;

public class Livros {
	private Formatos f;
	private String titulo;
	private int quantidade, preco;
	
	public Livros(String titulo, int quantidade) {
		this.titulo = titulo;
		this.quantidade = quantidade;
		this.f = null;
		this.preco=0;
	}
	public boolean getStatus() {							//verifica o status de livro 
		if(quantidade>0) {										//se qt for maior q 0
			return true;											//true
		}														
		return false;
	}
	public int getPreco(Formatos fo) {						//Recebe formto e define o preco de acordo com o mesmo
		switch(fo) {											//pega formato e pega o preco
			case PDF:
				this.preco = 40;
				break;
			case EPUB:
				this.preco = 20;
				break;
			case FISICO:
				this.preco = 80;
				break;
			default:
				System.out.println("formato invalido");	
				this.preco=0;
		}
		
		return this.preco;
				
	}
	
	public Formatos getFormato(int x) {							//retorna o formato
		switch(x) {											//pega formato e pega o preco
		case 40:
			this.f= Formatos.PDF;
			break;
		case 20:
			this.f = Formatos.EPUB;
			break;
		case 80:
			this.f = Formatos.FISICO;
			break;
		default:
			System.out.println("N�o a livros nesse valar");	
			this.f=null;
	}
		return this.f;
	}
	public String getTitulo() {
		return this.titulo;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void informacoes() {
		System.out.println("Titulo: "+titulo);
		System.out.println("Quantidade: "+quantidade);
		System.out.println("Formato: EPUB, PDF e FISICO");
	}
	public void retirar(int qt) {
		if(this.quantidade>=qt) {							//se estoque for maior ou igual qtd
			this.quantidade-=qt;
		}
	}
	
}
