import java.util.ArrayList;

public class Biblioteca {							
	private ArrayList<Estante> e;									//ARRAY
	private String nome;											//VARIAVEL
	
	public Biblioteca(String nome) {								//CONSTRUTOR
		this.nome = nome;											//INICIALIZANDO VARIAVEL E ARRAY NA CHAMADA
		e = new ArrayList<Estante>();				
	}
	////////////////////////////////////ADD/REMOVER////////////////////////////////////
	
	public void inserirEstante(Estante ep ){						//ADD ESTANTE NA BIBLIOTECA
		e.add(ep);													// e REPRESENTA ARRAY add ADICIONA A ESTANTE QUE VEM PELO PARAMETRO
	}
	
	public Estante remover(int x) {									//REMOVER	
		if(e.get(x).contarLi()==0){									//SE NA ESTANTE X N�O HOUVER LIVROS
			return e.remove(x);										//REMOVE E RETORNA ESTANTE REMOVIDA
		}else{														//SE N�O
			System.out.println("remova os livros primeiro");		//AVISA QUE TEM QUE ESTAR VAZIA
		}
		return null;												//RETORNA NULL
	}
	///////////////////////////////////PESQUISA///////////////////////////////////////
	
	public int buscaEstanteNome(String nomeEs) {					
		for(Estante estante: e) {									//FOR IT NA ESTRUTURA
			if(estante.getNmEstante().equals(nomeEs)){				//SE NOME DO OBJETO DA ESTRUTURA FOR IGUAL AO PASSADO NO PARAMETRO
				return e.indexOf(estante);							//RETORNA O INDICE DELE NA ESTRUTURA
			}
		}
		return-1;													//SE N�O EXISTE VOLTA -1
	}
	
	public int contador(){											//CONTADOR PRA SABER QUANTOS LIVROS HA NA BIBLIOTECA
		int c =0;													//VARIAVEL AUX DO TIPO DE RETORNO
		for(Estante estante: this.e) {								//FOR IT NAS ESTANTES
			c+=estante.contarLi();									//SOMAR A C QUANTIDADE DE LIVROS NA ESTANTE(METODO)
		}
		return c;													//RETORNA C
	}
	///////////////////////////////////EXIBIR/////////////////////////////////////////
	
	public void  ExibirPorCategoria(Categoria c, Tipo t) {
		for(Estante estante: this.e) {								//FOR IT
			if(estante.getC().equals(c) && t==Tipo.Estante) {		//SE CATEGORIA DA ESTANTE FOR IGUAL A PASSADA NO PARAMETRO PRINTA
				System.out.println("Nome da Estante: "+estante.getNmEstante()+".  Categoria: "+estante.getC());
				System.out.println("Livros: ");
				estante.getliv();									//PRINTA OS LIVROS DENTRO DA ESTANTE(METODO)
			}else {
				if(estante.getC().equals(c)) {
					estante.getAutor1();
				}
			}
		}
	}
	
	public void listaAutores(Categoria c) {
		ExibirPorCategoria(c, Tipo.Autor);
	}
	
	public void ExibirTodos() {		//POSSO MELHORAR
		Tipo t = Tipo.Estante;
		ExibirPorCategoria(Categoria.CIENCIA, t);							//PRINTA PELO METODO JA EXISTENTE
		ExibirPorCategoria(Categoria.FILOSOFIA, t);
		ExibirPorCategoria(Categoria.LITERATURA,t);
	}
	public String getNome() {										//RETORNA O NOME DA BIBLIOTECA
		return nome;
	}
	
}
