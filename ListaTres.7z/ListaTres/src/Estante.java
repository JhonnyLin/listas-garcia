import java.util.ArrayList;

public class Estante {
	private Categoria c;											//ENUM
	private String nmEstante;	
	private ArrayList<Livro> li;									//ARRAYLIST
	
	public Estante(String nmEstante, Categoria c) {					//CONSTRUTOR
		this.nmEstante = nmEstante;
		this.c = c;
		li = new ArrayList<Livro>();
	}
/////////////////////////////PEQUISA LIVRO/////////////////////////////////////
	
	public int inLivro(String nome) {
		for(Livro l: li) {
			if(l.getTitulo().equals(nome)) {					//VERIFICA NOME
				return li.indexOf(l);							//RETORNA INDICE
			}
		}
		System.out.println("livro n�o existe");					//SE N�O EXISTE RETORNA -1
		return -1;
	}

////////////////////////////////ADD/REMOVER/TROCA///////////////////////////////////
	public void addEstante(Livro l) {
		li.add(l);
	}
	
	public Livro removeLivro(int x) {							//REMOVER
		if(x>-1) {												//SE PARAMETRO MAIOR QUE -1
			return li.remove(x);								//REMOVE E RETORNA O LIVRO REMOVIDO DO ARRAY
		}
		return null;											// SE N�O NULL
	}
	
	public Livro troca(String livro, Estante y) {				//TROCA
		Livro e = null;											//CRIA UM OBJETO LIVRO
		 y.addEstante(e=removeLivro(inLivro(livro)));			//PROCURA LIVRO PELO NOME(METODO)
		 														//REMOVE O LIVRO ENCONTADO DA ESTANTE E PASSA PRA e(METODO)
		 														//NA ESTANTE RECEBIDA NO PARAMETRO ADICIONA O LIVRO QUE ESTA EM e(METODO DE OUTRO OBJETO)
		 return e;												//RETORNA e
	}
	
	//////////////////////////////GETS///////////////////////////////
	public String getNmEstante() {
		return this.nmEstante;
	}
	public Categoria getC() {
		return this.c;
	}
	public int getliv() {										//PRINTA LIVROS E PASSA INT PARA VERIFICA��O DA REMO��O DA ESTANTE
		int c=0;
		for(Livro liv: li){
			System.out.println("Titulo: "+liv.getTitulo()+". Nome Autor: "+liv.getAutor()+". Ano: "+liv.getAno()+".");
			c++;
		}
		return c;
	}
	public void getAutor1() {
		for(Livro liv: li){
			System.out.println("Nome Autor: "+liv.getAutor()+".");
		}
	}
	public int contarLi() {										//QUANTIDADE DE LIVROS
		return li.size();										//RETORNA TAMANHO DO ARRAY
	}
	
	
}
