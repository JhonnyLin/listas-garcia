
public class Teste {

	public static void main(String[] args) {
		
		Tipo t= Tipo.Estante;
		Biblioteca b = new Biblioteca("Book Hause");				//CRIA BIBLIOTECA
		Estante e1 = new Estante("Aventura", Categoria.LITERATURA);			//CRIA AS ESTANTES
		Estante e2 = new Estante("ADM", Categoria.CIENCIA);
		Estante e3 = new Estante("ADS", Categoria.CIENCIA);
		Estante e4 = new Estante("Grecia", Categoria.FILOSOFIA);
		Livro l1 = new Livro("Kkkk","Mack",2019);					//CRIA OS LIVROS
		Livro l2 = new Livro("Haha","Amck",2018);
		Livro l3 = new Livro("Oshi","mak",2017);
		Livro l4 = new Livro("Uhum","Oack",2016);
		Livro l5 = new Livro("OMds","ack",2015);
		Livro l6 = new Livro("Putz","Hack",2014);
		Livro l7 = new Livro("Haaa","ck",2013);
		b.inserirEstante(e1);										//ADICIONA OS ESTANTES A BIBLIOTECA
		b.inserirEstante(e2);
		b.inserirEstante(e3);
		b.inserirEstante(e4);
		System.out.println(b.getNome());							//PRINTA O NOME DA BIBLIOTECA
		b.ExibirPorCategoria(Categoria.CIENCIA,t);					//PRINTA ESTANTES POR CATEGORIA
		b.ExibirPorCategoria(Categoria.FILOSOFIA,t);
		b.ExibirPorCategoria(Categoria.LITERATURA, t);
		e1.addEstante(l1);											//ADD LIVROS NAS ESTANTES
		e1.addEstante(l2);
		e2.addEstante(l3);
		e2.addEstante(l4);
		e3.addEstante(l5);
		e3.addEstante(l6);
		e4.addEstante(l7);
		b.listaAutores(Categoria.CIENCIA);
		b.ExibirTodos();											//PRINTA TODOS OS LIVROS
		System.out.println(b.contador());							//PRINTA QUANTIDADE DE LIVROS
		b.remover(b.buscaEstanteNome("ADM"));						//CHAMA O REMOVER MAS COMO TEM LIVROS N�O VAI PEDIR PRA TIRAR O LIVRO
		System.out.println(e4.removeLivro(e4.inLivro("Haaa")));		//REMOVE O LIVRO DA ESTANTE 4
		System.out.println(e4.removeLivro(e4.inLivro("Haaa")));		//TENTA TIRAR NOVAMENTE POREM N�O O ENCONTRA VOLTA NULL
		System.out.println(b.remover(b.buscaEstanteNome("Grecia")));//REMOVE A ESTANTE //PRIMEIRO METODO OPTATIVO
		e1.troca("Haha", e2);										//TROCA O LIVRO DE ESTANTE // SEGUNDO METODO OPTIVO
		b.ExibirTodos();											//EXIBE TUDO COM AS ALTERA��ES
	}

}
