
public class Livro {
	private String titulo, nmAutor;
	private int ano;
	
	public Livro(String titulo, String nmAutor, int ano) {
		this.titulo = titulo;
		this.nmAutor = nmAutor;
		this.ano = ano;
	}
	////////////////////////////////GETS///////////////////////////////
	public String getTitulo() {
		return this.titulo;
	}
	public String getAutor() {
		return this.nmAutor;
	}
	public int getAno() {
		return this.ano;
	}
}
