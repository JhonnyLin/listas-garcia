
public enum Tipo {
	Estante, Autor;
}
