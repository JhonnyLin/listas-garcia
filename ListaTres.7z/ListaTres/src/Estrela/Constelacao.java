package Estrela;

import java.util.ArrayList;

public class Constelacao {
	private ArrayList<Estrela> es;									//ARRAY DE ESTRELA
	private String nome;	
	public Constelacao(String nome) {											//AO CHAMAR CONSTELA��O INICIA O ARRAY DE ESTRELA
		es = new ArrayList<Estrela>();
		this.nome = nome;
	}
////////////////////////////////////////METODOS/////////////////////////////////////////////
	public void adicionarEstrela(Estrela estrela) {					//ADICIONA UMA ESTRELA AO ARRAY
		if(estrela != null) {											//SE DIFERENTE DE NULL
			es.add(estrela);												//CHAMA ARRAY E O METODO ADD E PASSA ESTRELA PELO PARAMETRO
		}
	}
	
	public void infoEstrelas() {									//PRINTAR AS ESTRELAS
		for(Estrela e: es) {											//UM FOR IT OU SEJA ELE PASSA POR TODOS OS OBJETOS DENTRO DO FOR
																		//DECLARA UM OBJETO DO TIPO QUE VAI DENTRO DO ARRAY, E COLOCA A VARIEAVEL QUE REPRESENTA
				e.mostrar();												//METODOS VOID N�O SE UTILIZA SYSO, PQ ELE N�O TEM RETORNO
		}
		System.out.println("Tempertura Constela��o: "+tempConstelacao()+".");//FICOU DE FORA PQ DEVE SER PRINTADO S� NO FIM PQ � PRA SER EXIBIDO UMA VEZ
	}
	
	public double tempConstelacao() { 								//SOMA AS TEMPERATURAS DAS ESTRELAS COM UMA VARIAVEL AUX, MAS PODERIA SER FEITA DENTRO DO MOSTRAR
		double aux=0;													//VARIAVEL DO MESMO TIPO DO RETORNO
		for(Estrela e: es) {											//FOR IT
			aux += e.getTempE();											//VARIEVEL AUX MAIS TEMPERATURA DO OBJETO DO ARRAY(ISSO ATE PASSAR POR TODOS)
		}
		return aux;														//RETORNA O AUX
	}
	///////////////////////////////////GET//////////////////////////
	public String getNome() {
		return nome;
	}
}
