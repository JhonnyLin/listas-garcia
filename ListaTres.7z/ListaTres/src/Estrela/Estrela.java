package Estrela;

public class Estrela {
	private String nome, cor;													//DECLARA��ES
	private double temperatura;
	
	public Estrela(String nome, String cor, double temperatura) {				//CONSTRUTOR
		this.nome = nome;														//INICIALIZA��O DAS VARIAVEIS
		this.cor = cor;
		this.temperatura = temperatura;
	}
	//////////////////////////////////////METODOS////////////////////////
	public void mostrar() {														//VAI PRINTAR OS DADOS UTILIZANDO O GETS
		System.out.println("Nome: "+getNomeE()+" .Cor: "+getCorE()+". Temperatura: "+getTempE());
	}
	/////////////////////////////////////GETS////////////////////
	public String getNomeE() {													//NECESSARIO PARA TER ACESSO AS VARIAVEIS(PRIVATE)
		return this.nome;
	}
	public String getCorE() {
		return this.cor;
	}
	public double getTempE() {
		return this.temperatura;
	}
}
