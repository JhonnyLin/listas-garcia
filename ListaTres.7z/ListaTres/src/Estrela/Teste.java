package Estrela;

public class Teste {

	public static void main(String[] args) {
		Constelacao c = new Constelacao("Sakura");					//CRIA A CONSTELA��O SAKURA
		Estrela e0 = new Estrela("Rum","vermelha",29.55);			//CRIA AS ESTRELAS
		Estrela e1 = new Estrela("oxi","azul",10.45);
		Estrela e2 = new Estrela("ixi","laranja",39.55);
		Estrela e3 = new Estrela("hum","amarela",20.45);
		Estrela e4 = new Estrela("aff","roxo",59.55);
		Estrela e5 = new Estrela("kkk","verde",90.55);
		c.adicionarEstrela(e0);										//ADICIONA AS ESTRELAS A CONSTELA��O
		c.adicionarEstrela(e1);
		c.adicionarEstrela(e2);
		c.adicionarEstrela(e3);
		c.adicionarEstrela(e4);
		c.adicionarEstrela(e5);
		c.infoEstrelas();											//EXIBE TODAS AS ESTRELAS DENTRO DA COSTRELA��O
		
	}

}
