package Autenticacao;

public class Group extends Regular {

	public void groupBoard() {
		System.out.println("Voc� pode remover usuarios do seu grupo");
	}
	
}
