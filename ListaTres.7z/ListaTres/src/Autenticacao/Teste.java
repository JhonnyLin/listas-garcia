package Autenticacao;

public class Teste {

	public static void main(String[] args) {
		Usuario u0 = new Usuario("affs", TipoUser.Regular);					//CRIA USER
		Usuario u1 = new Usuario("sffa", TipoUser.Group);
		Usuario u2 = new Usuario("aham", TipoUser.Root);
		Usuario u3 = new Usuario("maha", TipoUser.Guest);
		Sistema s = new Sistema();											//CRIA SISTEMA
		s.add(u0);															//ADD USER AO SISTEMA
		s.add(u1);
		s.add(u2);
		s.add(u3);
		s.inicio(s.obj(s.autenti("sffa")));									//VERIFICA A EXISTENCIA DE USUARIO, PASSA ELE PRO DAR INICIO AO SISTEMA
		
	}

}
