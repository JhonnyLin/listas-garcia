package Autenticacao;

public class Regular {
		
	public void dashboard(Usuario u) {
		u.boasVindas();
		switch (u.getTipo().toString()) {
		case "Root":
			u.permicaoRoot();
			break;
		case "Group":
			u.permicaoGroup();
			break;
		case "Regular":
			u.permicaoRegular();
			break;
		case "Guest":
			u.permicaoGuest();
			break;
		default:
			System.out.println("Usuario fora do padr�o bloqueando acesso........");
			break;
		}
	}
	
}
