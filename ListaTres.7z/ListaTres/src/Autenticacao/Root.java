package Autenticacao;

public class Root extends Regular {

	public void excluirTodos() {
		System.out.println("Voc� pode apagar todos");
	}
	
}
