package Autenticacao;

public class Guest extends Regular{

	

}
