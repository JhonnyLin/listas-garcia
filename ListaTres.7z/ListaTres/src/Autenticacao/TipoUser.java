package Autenticacao;

public enum TipoUser {
	Guest/*Convidado*/,	Regular, Group, Root;
}
