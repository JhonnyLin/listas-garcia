package Autenticacao;

import java.util.ArrayList;

public class Sistema {
	ArrayList<Usuario> a ;
	
	public Sistema() {								//CONSTRUTOR
		 a = new ArrayList<Usuario>();
	}
	
	public void add(Usuario e) {					//ADD USER
		a.add(e);
	}
	
	public int autenti(String lg){					//VERIFICA SE USER EXISTE E DEVOLVE INDICE
		for(Usuario u: a) {
			if(u.getLogin().equals(lg)) {
				return a.indexOf(u);
			}
		}
		return -1;
	}
	
	public Usuario obj(int x) {						//PEGA INDICE E DEVOLVE USUARIO
		if(x!=-1) {
			return a.get(x);	
		}
		return null;
	}
	
	public void inicio(Usuario u) {					//INICIA O SISTEMA DE ACORDO COM O USUARIO
		switch (u.getTipo().toString()) {
		case "Root":
			Root rt = new Root();
			rt.dashboard(u);
			rt.excluirTodos();
			break;
		case "Group":
			Group gp = new Group();
			gp.dashboard(u);
			gp.groupBoard();
			break;
		case "Regular":
			Regular rg = new Regular();
			rg.dashboard(u);
			break;
		case "Guest":
			Guest gt = new Guest();
			gt.dashboard(u);
			break;
		default:
			System.out.println("Usuario fora do padr�o bloqueando acesso........");
			break;
		}
	}
}
