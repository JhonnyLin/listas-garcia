package Autenticacao;

public class Usuario {
	private String login;
	private TipoUser t;
	public Usuario(String login, TipoUser t) {
		this.login = login;
		this.t = t;
	}
	
	public void boasVindas() {
		System.out.println("Bem vindo "+getLogin());
	}
	
///////////////////////////////////////DESPEDIDA//USER//////////////
	
	public void despedidaRegular() {
		System.out.println("Volte Logo...");
	}
	
	public void despedidaGuest() {
		System.out.println("Se cadastre para melhor intera��o....");
	}
	
	public void despedidaGroup() {
		System.out.println("Seus grupos estaram te aguardando....");
	}
	
	public void despedidaRoot() {
		System.out.println("V�, mas volte o quanto antes precisamos de vc......");
	}
	
//////////////////////////////////////PERMICAO//////////////////////
	//FALTA FAZER
	public void permicaoRegular() {
		System.out.println("Regular:");
	}
	
	public void permicaoGuest() {
		System.out.println("Convidado:");
	}
	
	public void permicaoGroup() {
		System.out.println("Adm do Grupo:");
	}
	
	public void permicaoRoot() {
		System.out.println("ADM:");
	
	}
///////////////////////////////////////GETS/////////////////////////
		
	public String getLogin() {
		return login;
	}
	
	public TipoUser getTipo() {
		return t;
	}
	
}
