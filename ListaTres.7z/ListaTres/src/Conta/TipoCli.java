package Conta;

public enum TipoCli {
	VIP, PLEMIUM, REGULAR;
}
