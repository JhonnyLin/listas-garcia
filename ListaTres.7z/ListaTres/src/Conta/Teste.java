package Conta;

public class Teste {

	public static void main(String[] args) {
		Cliente c0 = new Cliente(TipoCli.VIP, "Jhonny",1000);
		Cliente c1 = new Cliente(TipoCli.PLEMIUM, "Santos",1000);
		Cliente c2 = new Cliente(TipoCli.REGULAR, "Lin",1000);
		c0.saldoC();
		c1.nomeC();
		c2.tipoCont();
		c0.infConta();
		c1.infConta();
		c2.infConta();
	}
		

}
