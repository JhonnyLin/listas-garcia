package Conta;

public class ContaC{											
	private double saldo;											//DECLARA��O DE VARIAVEIS GLOBAIS
	private TipoCli t;
	private String nome;
	public ContaC(TipoCli t, String nome, double saldo) {			//CONSTRUTOR(PARAMETROS)
		this.t = t;													//PASANDO PARAMETRO PARA VARIAVEIS GLOBAIS
		this.nome = nome;
		this.saldo = saldo;
	}
//////////////////////////////////GETS////////////////////////////////
	
	public TipoCli getTipo() {										//PASSA DADOS DAS VARIAVEIS
		return this.t;
	}

	public String getNome() {
		return this.nome;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
///////////////////////////////METODO//////////////////////////////	
	
	public double tarifa() {										//CALCULA TARIFA DE ACORDO COM O TIPO DE CLIENTE
		TipoCli y = getTipo();										//VARIAVEL AUX QUE RECEBE O TIPO PELO METODO
		if(y==TipoCli.PLEMIUM) {									//SE IGUAL A A TIPO ? RETURN ?
			return saldo*0.02;
		}else {														//SE N�O PROXIMA CONDI��O
			if(y==TipoCli.REGULAR) {								
				return saldo*0.01;
			}else {													//SE N�O RETURN
				return saldo*0.04;
			}
		}
	}

///////////////////////////////////////////////////////////////////
	
}
	

