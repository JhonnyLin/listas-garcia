package Conta;

public class Cliente extends ContaC {								//CLASSE X � UMA EXTEN��O DE OUTRA CLASSE Y 

	public Cliente(TipoCli t, String nome, double saldo) {			//CONSTRUTOR RECEBE TODOS OS PARAMETROS QUE A CLASSE Y DEVE RECEBER
																	//PODE RECEBER TAMBEM PARAMETROS ESPECIFICOS PARA A CLASSE X
		super(t, nome, saldo);										//PASSANDO PARA Y POIS ESTA TUDO DECLARAO LA
	}
//////////////////////////////EXIBIR//TUDO///////////////////////////////////	
	public void infConta(){	
		System.out.println("Cliente");
		nomeC();													//METODOS INDIVIDUAIS 
		tipoCont();
		saldoC();
		tarifaC();
	}
////////////////////////////////EXIBI��O//INDIVIDUAL///////////////////////////
	public void saldoC() {
		System.out.println("Saldo R$: "+getSaldo()+".");
	}
	public void nomeC() {
		System.out.println("Nome: "+getNome()+".");
	}
	public void tipoCont() {
		System.out.println("Tipo Cliente: "+getTipo()+".");
	}
	public void tarifaC() {
		System.out.println("Tarifa R$: "+tarifa()+".");
	}
	

}
