
public enum Categoria {
	CIENCIA,LITERATURA, FILOSOFIA;
}

