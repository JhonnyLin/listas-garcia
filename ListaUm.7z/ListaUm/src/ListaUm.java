import ex2.TrianguloEquilatero;

//import ex2.Eq2Grau;
//import ex2.Lampada;
//import ex2.Porta;

//>>>duvidas<<<
//o costrutor so ira iniciar os parametros que vao vir de fora?
//melhor forma de arredondamento ex area
public class ListaUm {

	public static void main(String[] args) {
		/*//Ex CHURRASCO 
		Pessoa p = new Pessoa("joao", "masculino", 15, true);	//instancia a classe Pessoa e passa os valores
		Churrasco c = new Churrasco(p);							//instancia churrasco e passa pessoa como parametro
		System.out.println(c.verificarConsumo());				//chama o metodo verifica consumo e printa
		*/
		/*//EX LAMPADA
		Lampada l = new Lampada(2);				//qtd de quebra 2
		System.out.println(l.interruptor());	//ligada click 1
		System.out.println(l.interruptor());	//desliga click 2(quebra)
		System.out.println(l.interruptor());	//click 3 (n�o Liga)
		System.out.println(l.interruptor());	//click 4 (n�o liga)
		*/
		/*//EX PORTA
		Porta d = new Porta();										//instancia porta
		d.abrir();													//abre 1
		d.fechar();													//fecha
		d.abrir();													//abre 2
		d.abrir();													//volta que ja esta aberta
		d.fechar();													//fecha
		d.fechar();													//voltar q ja esta fechada
		System.out.println("porta aberta? "+d.isOpen);				//printa fechado
		System.out.println("porta aberta "+d.numAberturas+" vezes");//printa 2
		*/
		 /*//EX EQUA��O 2 GRAU
		Eq2Grau e = new Eq2Grau(2,8,-24);							//intancia equa��o
		System.out.println("Delta: "+e.delta());					//chama e printa delta
		if(e.raiz1()<=0) {											//se raiz menor que zero printa NaN
			System.out.println("Raiz 1: NaN");
		}else {														//se maior printa o resultado
			System.out.println("Raiz positiva: "+e.raiz1());
		}
		if(e.raiz2()<=0) {
			System.out.println("Raiz 2: NaN");
		}else {
			System.out.println("Raiz positiva: "+e.raiz2());
		}*/
		/*//EX TRIANGULO EQUILATERO
		TrianguloEquilatero t = new TrianguloEquilatero(22);
		t.calcArea();
		t.calcPerimetro();
		System.out.println("Area:"+t.getArea());
		System.out.println("Perimetro: "+t.getPerimetro());
		*/
		
	}

}
