
/*Dada a classe Pessoa, que possui os atributos: String
nome, String sexo, int idade, boolean vegetariana. Fa�a agora uma
classe Churrasco que possua:
Atributos: qtdCarne(double);
M�todo: verificarConsumo(): Recebe via par�metro uma Pessoa, e com
isto define a consuma��o m�dia de carne(quantidade de carne consumida), pessoas de 0 a 3 anos n�o consomem, vegetarianos tamb�m n�o.
Pessoas de 4 a 12 anos consomem 1 kilo de carne e de 13 anos em diante 2 kilos de carne.
*/
public class Pessoa {
	String nome, sexo;
	int idade;
	boolean vegetariana;
	
	public Pessoa(String nome, String sexo, int idade, boolean vegetariana) {
		this.nome = nome;
		this.idade = idade;
		this.sexo = sexo;
		this.vegetariana = vegetariana;
	}
	
}
