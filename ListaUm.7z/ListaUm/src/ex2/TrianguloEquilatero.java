package ex2;

public class TrianguloEquilatero {
	private int lado, perimetro;
	private double area;
	
	public TrianguloEquilatero(int lado) {
		this.lado = lado;
	}
	public void calcPerimetro() {
		perimetro= lado*3;
	}
	/*divide a raiz de 3 que s�o os lados por 2 e multiplica pelos lados*/
	public void calcArea() {
		 area = lado*( Math.sqrt(3)/2);
	}
	public int getPerimetro() {
		return perimetro;
	}
	public double getArea() {
		return area;
	}
	
}
