/*
 Implemente a classe Eq2Grau que possua:
 Atributos: a,b e c (doubles);
 M�todos: delta(): retorna o delta da equa��o;
 raiz1(): retorna a primeira raiz se   0, se n�o retorna NaN;
 raiz2(): retorna a segunda raiz se   0, se n�o retorna NaN.*/
package ex2;

public class Eq2Grau {
	public double a,b,c,delta;
	
	public Eq2Grau(double a, double b, double c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}
	/*
	 * Math.pow POTENCIA��O, 1� ARGUMENTO � A BASE, 2� O EXPOENTE
	 * FAZ A POTENCIA��O
	 * MULTIPLICA a POR c
	 * MULTIPLICA O RESULTADO POR 4
	 * E SUBITRAI DO RESULTADO DA POTENCIA
	 */
	public double delta() {
		return delta = (Math.pow(b, 2)-(4*(a*c)));
	}
	/*
	 * Math.sqtr RAIZ QUADRADA DE ATRIBUTO(DELTA)
	 * PASSA B PRA NEGATIVO
	 * SOMA A raiz COM b
	 * MULTIPLICA 2 POR a
	 * E DIVIDE O RESULTADADO DE raiz E b POR A MULTIPLICA��O DE a POR 2
	 */
	public double raiz1() {
		return (Math.sqrt(delta)+(-b))/(2*a);
	}
	
	 //Subtrai A raiz COM b
	 public double raiz2() {
		return (Math.sqrt(delta)-(-b))/(2*a);
	}
}
