/* OBS: O atributo numAberturas deve contar o total de
 *  aberturas de todas as portas poss�veis.*/
package ex2;

public class Porta {										//Implemente a classe Porta que possua:
	public boolean isOpen = false;						 	//Atributos: isOpen(boolean), numAberturas(int)
	public int numAberturas =0;
		
	public void abrir() {									//abrir(): abre a porta e conta 1 na contagem de aberturas;
		if(isOpen) {										//se porta estiver aberta printa PORTA JA ABERTA
			System.out.println("Porta ja esta aberta");		
		}else {												//se fechada
			isOpen = true;									//abre porta
			numAberturas++;									//soma 1 nas aberturas
			System.out.println("Open");						// printa aberta
		}
	}
	public void fechar() {									//fechar(): fecha a porta
		if(isOpen) {										//se porta aberta
			isOpen = false;									//fecha
			System.out.println("Close");					//printa fechada
		}else {												//se fechada
			System.out.println("Porta ja esta fechada");	//printa PORTA JA FECHADA
		}
	}

}
