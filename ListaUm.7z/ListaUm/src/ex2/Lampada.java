/*
 * Implemente uma classe L�mpada. 
Toda l�mpada possui um estado (on/off ).
Sabe-se que as l�mpadas podem ter seu estado trocado (click do interruptor).
Ser� necess�rio tamb�m uma funcionalidade para checar o estado atual da l�mpada.
Uma l�mpada estraga ap�s uma quantidade de clicks (o click n�o troca mais o estado deixando-a
eternamente em off ) e esta depende da l�mpada. 
Implemente esta situa��o e seu teste.
*/

package ex2;

public class Lampada {							//classe lampada
	boolean  lampada = false;					//status lampada
	int qtdClick =0, qtdQuebra;					//quantidade de clicks e o maximo
	
	public Lampada(int qtdQuebra) {
		this.qtdQuebra = qtdQuebra;
	}
	public boolean interruptor() {						//metodo interrupitor
		qtdClick++;								//toda vez que for chamado aumenta o click
		if(qtdClick>qtdQuebra) {				//verifica se a quantidade de click � maior que quebra
			lampada = false;					//se true lampada desliga
		}else {									//se n�o entra em outro if
			if(lampada) {						//se ligada(true) ela desliga(false)
				lampada = false;			
			}else {
				lampada = true;					//se desligada(false) ela liga (true)
			}
		}
		return lampada;							//retorna o status da lampada
	}
}
