package ex2;

public class Adivinha {
	private int menor, maior;
	
	public Adivinha(int menor, int maior) {
		this.maior= maior;
		this.menor= menor;
	}
	public int metrica() {
		
		return 0;
	}
}
