/*classe Churrasco que possua:
Atributos: qtdCarne(double);
M�todo: verificarConsumo(): Recebe via par�metro uma Pessoa, e com
isto define a consuma��o m�dia de carne(quantidade de carne consumida), pessoas de 0 a 3 anos n�o consomem, vegetarianos tamb�m n�o.
Pessoas de 4 a 12 anos consomem 1 kilo de carne e de 13 anos em diante 2 kilos de carne.
*/

public class Churrasco {
	double mCarne;
	Pessoa p;
		
	public Churrasco(Pessoa p) {
		this.p = p;
	}
	
	public double verificarConsumo() {
		if(p.idade<=3 || p.vegetariana) {
			
		}else {
			if(p.idade>=13) {
				mCarne = 2;
			}else {
				mCarne=1;
			}
		}
		return mCarne;
	}
}
